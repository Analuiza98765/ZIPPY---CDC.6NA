# Zippy — Simulador de Robô Móvel

Simulador de navegação de robô móvel em uma planta residencial, com física diferencial,
LiDAR de 360°, odometria, grade de ocupação, planejamento A* e replanejamento.

## Requisitos

- Python 3.10 ou superior
- pygame 2.5 ou superior
- numpy 1.24 ou superior

Instale as dependências:

```bash
python -m pip install -r requirements.txt
```

## Executar

Mantenha estes arquivos na mesma pasta:

- `Projeto_Zippy.py`
- `Planta_Baixa_Modern_House.jpeg`
- `requirements.txt`

Inicie com:

```bash
python Projeto_Zippy.py
```

## Navegação e segurança

- O planejador A* trabalha em uma grade de ocupação inflada pelo raio do robô
  e por uma margem de segurança.
- A suavização do caminho verifica a linha com amostragem densa e rejeita
  diagonais que cortem quinas de células ocupadas.
- O controlador reduz a velocidade e o avanço de mira para contornar curvas
  com menor risco de cortar cantos.
- A física verifica o volume varrido pelo robô durante cada passo, impedindo
  que atravesse paredes e obstáculos.
- Os vãos das portas fazem parte da geometria navegável, mas não são desenhados
  como linhas brancas na interface.
- Passagens sob móveis são liberadas somente para móveis marcados como
  transitáveis e cuja altura livre estimada seja maior que a altura do robô
  mais a margem vertical. Apoios continuam sendo obstáculos.

## Ajustes físicos

A planta é uma imagem superior e não informa alturas reais. Os parâmetros
`ROBOT_HEIGHT`, `HEIGHT_MARGIN` e os valores de `MOVEIS_PASSAVEIS` são
estimativas configuráveis. Antes de usar em um robô físico, meça o equipamento,
as alturas dos móveis, as larguras das portas e calibre a escala da planta.

A margem de navegação é definida por `INFLATE_CELLS`; aumentá-la torna o trajeto
mais conservador, mas pode impedir a passagem por corredores estreitos.

## Controles

Os controles e atalhos disponíveis são apresentados na barra inferior e no
painel lateral do simulador.
